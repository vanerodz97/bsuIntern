from django.apps import AppConfig


class MlapiConfig(AppConfig):
    name = 'mlapi'
